const express = require("express");

const router = express.Router();

router.get("https://agrocotizador.com.ar", (req, res) => {
  res.send("Home Page");
});

module.exports = router;
